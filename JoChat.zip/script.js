
function sendMessage(){
    let input=document.getElementById('user-input');
    let box=document.getElementById('chat-box');
    let text=input.value.trim();
    if(!text) return;
    box.innerHTML += "<div><b>You:</b> "+text+"</div>";
    box.innerHTML += "<div><b>JoChat:</b> جاري معالجة الرسالة...</div>";
    input.value="";
    box.scrollTop=box.scrollHeight;
}
